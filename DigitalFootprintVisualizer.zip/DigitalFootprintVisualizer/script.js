"use strict";

// Assessment elements
const assessmentForm = document.getElementById("assessment-form");
const questionCount = document.getElementById("question-count");
const progressFill = document.getElementById("progress-fill");
const progressTrack = document.getElementById("progress-track");
const formMessage = document.getElementById("form-message");

const scoreValue = document.getElementById("score-value");
const scoreStatus = document.getElementById("score-status");
const scoreExplanation = document.getElementById("score-explanation");
const resultHeading = document.getElementById("result-heading");
const scoreCircle = document.querySelector(".score-circle");
const recommendationList = document.getElementById("recommendation-list");

const restartButton = document.getElementById("restart-button");

// Checklist elements
const checklistItems = document.querySelectorAll(
    ".checklist-items input[type='checkbox']"
);
const checklistProgress = document.getElementById("checklist-progress");
const checklistFill = document.getElementById("checklist-fill");
const checklistTrack = document.getElementById("checklist-track");
const resetChecklistButton = document.getElementById("reset-checklist");

// Storage keys
const CHECKLIST_KEY = "footprintPrivacyChecklist";
const QUESTION_COUNT = 8;
const CHECKLIST_COUNT = checklistItems.length;

// Privacy recommendations linked to each question
const recommendations = [
    {
        question: "q1",
        title: "Strengthen your passwords",
        description:
            "Use long, unique passwords for different accounts. A reputable password manager can help you manage them.",
        icon: "🔑"
    },
    {
        question: "q2",
        title: "Enable two-factor authentication",
        description:
            "Turn on two-factor authentication for important accounts whenever it is available.",
        icon: "🛡️"
    },
    {
        question: "q3",
        title: "Review social media privacy",
        description:
            "Check who can view your posts, profile details and friend lists. Choose settings that suit your privacy needs.",
        icon: "👁️"
    },
    {
        question: "q4",
        title: "Think before sharing",
        description:
            "Avoid publishing sensitive personal information, private documents or live location details unnecessarily.",
        icon: "💭"
    },
    {
        question: "q5",
        title: "Recognize suspicious messages",
        description:
            "Check unexpected links, sender details and urgent requests carefully. Visit official websites directly when in doubt.",
        icon: "🔎"
    },
    {
        question: "q6",
        title: "Check app permissions",
        description:
            "Review camera, microphone, contacts and location access. Remove permissions that an app does not need.",
        icon: "⚙️"
    },
    {
        question: "q7",
        title: "Keep software updated",
        description:
            "Install browser, operating system and app updates to receive important security fixes.",
        icon: "🔄"
    },
    {
        question: "q8",
        title: "Review tracking preferences",
        description:
            "Review cookie choices and available tracking controls. Reject optional tracking when you prefer not to allow it.",
        icon: "🌐"
    }
];

// Safely read checklist progress from this browser
function loadChecklist() {
    try {
        const saved = localStorage.getItem(CHECKLIST_KEY);

        if (!saved) {
            return [];
        }

        const parsed = JSON.parse(saved);

        if (
            !Array.isArray(parsed) ||
            !parsed.every(
                value =>
                    Number.isInteger(value) &&
                    value >= 0 &&
                    value < CHECKLIST_COUNT
            )
        ) {
            return [];
        }

        return [...new Set(parsed)];
    } catch (error) {
        return [];
    }
}

// Safely save checklist progress
function saveChecklist() {
    const completed = [];

    checklistItems.forEach((item, index) => {
        if (item.checked) {
            completed.push(index);
        }
    });

    try {
        localStorage.setItem(
            CHECKLIST_KEY,
            JSON.stringify(completed)
        );
    } catch (error) {
        // The checklist still works if browser storage is unavailable.
    }
}

// Update checklist progress and progress bar
function updateChecklistProgress() {
    let completed = 0;

    checklistItems.forEach(item => {
        if (item.checked) {
            completed++;
        }
    });

    const percentage = Math.round(
        (completed / CHECKLIST_COUNT) * 100
    );

    checklistProgress.textContent =
        `${completed} of ${CHECKLIST_COUNT} completed`;

    checklistFill.style.width = `${percentage}%`;

    checklistTrack.setAttribute("aria-valuenow", completed);
    checklistTrack.setAttribute("aria-valuemax", CHECKLIST_COUNT);
}

// Restore previously saved checklist items
function restoreChecklist() {
    const savedItems = loadChecklist();

    checklistItems.forEach((item, index) => {
        item.checked = savedItems.includes(index);
    });

    updateChecklistProgress();
}

// Update answered-question count and progress bar
function updateAssessmentProgress() {
    let answered = 0;

    for (let i = 1; i <= QUESTION_COUNT; i++) {
        const selected = assessmentForm.querySelector(
            `input[name="q${i}"]:checked`
        );

        if (selected) {
            answered++;
        }
    }

    questionCount.textContent =
        `${answered} / ${QUESTION_COUNT} answered`;

    const percentage = Math.round(
        (answered / QUESTION_COUNT) * 100
    );

    progressFill.style.width = `${percentage}%`;
    progressTrack.setAttribute("aria-valuenow", answered);

    return answered;
}

// Read and validate all eight answers
function getAssessmentAnswers() {
    const answers = [];

    for (let i = 1; i <= QUESTION_COUNT; i++) {
        const selected = assessmentForm.querySelector(
            `input[name="q${i}"]:checked`
        );

        if (!selected) {
            return null;
        }

        const value = Number(selected.value);

        if (![0, 1, 2].includes(value)) {
            return null;
        }

        answers.push({
            question: `q${i}`,
            value: value
        });
    }

    return answers;
}

// Display recommendations based on the user's answers
function displayRecommendations(answers) {
    recommendationList.replaceChildren();

    const needsAttention = recommendations.filter(item => {
        const answer = answers.find(
            response => response.question === item.question
        );

        return answer && answer.value < 2;
    });

    if (needsAttention.length === 0) {
        const message = document.createElement("div");
        message.className = "empty-state";

        const title = document.createElement("h3");
        title.textContent = "Great privacy habits!";

        const description = document.createElement("p");
        description.textContent =
            "You reported consistently following all eight habits. " +
            "Keep reviewing your settings as apps and services change. " +
            "Remember, this result is based on your answers.";

        message.append(title, description);
        recommendationList.appendChild(message);
        return;
    }

    needsAttention.forEach(item => {
        const card = document.createElement("article");
        card.className = "recommendation-card";

        const icon = document.createElement("div");
        icon.className = "recommendation-icon";
        icon.setAttribute("aria-hidden", "true");
        icon.textContent = item.icon;

        const content = document.createElement("div");

        const title = document.createElement("h3");
        title.textContent = item.title;

        const description = document.createElement("p");
        description.textContent = item.description;

        content.append(title, description);
        card.append(icon, content);
        recommendationList.appendChild(card);
    });
}

// Calculate and display the educational score
function calculateScore(answers) {
    const totalPoints = answers.reduce(
        (total, answer) => total + answer.value,
        0
    );

    const maximumPoints = QUESTION_COUNT * 2;

    const score = Math.round(
        (totalPoints / maximumPoints) * 100
    );

    scoreValue.textContent = score;

    // Update the visual score ring
    const angle = score * 3.6;

    scoreCircle.style.background =
        `conic-gradient(
            var(--purple) 0deg,
            var(--cyan) ${angle}deg,
            #273149 ${angle}deg,
            #273149 360deg
        )`;

    if (score >= 80) {
        scoreStatus.textContent = "Strong reported habits";
        scoreExplanation.textContent =
            "Your answers suggest good privacy habits. " +
            "Keep reviewing them regularly.";
    } else if (score >= 50) {
        scoreStatus.textContent = "Room to improve";
        scoreExplanation.textContent =
            "You already follow some useful habits. " +
            "Focus on the recommendations below to improve further.";
    } else {
        scoreStatus.textContent = "Start with the basics";
        scoreExplanation.textContent =
            "Your answers suggest several habits to work on. " +
            "Choose a few practical steps and build from there.";
    }

    resultHeading.textContent = "Your privacy snapshot";

    displayRecommendations(answers);
}

// Process assessment submission
assessmentForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const answered = updateAssessmentProgress();

    if (answered !== QUESTION_COUNT) {
        formMessage.textContent =
            `Please answer all ${QUESTION_COUNT} questions. ` +
            `${answered} of ${QUESTION_COUNT} are complete.`;

        const firstUnanswered = assessmentForm.querySelector(
            "fieldset:not(:has(input:checked)) input"
        );

        if (firstUnanswered) {
            firstUnanswered.focus();
        }

        return;
    }

    const answers = getAssessmentAnswers();

    if (!answers) {
        formMessage.textContent =
            "Please check your answers and try again.";
        return;
    }

    formMessage.textContent = "";
    calculateScore(answers);

    // Bring results into view on smaller screens
    document.getElementById("results").scrollIntoView({
        behavior: window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        ).matches ? "auto" : "smooth",
        block: "nearest"
    });
});

// Update progress as users select answers
assessmentForm.addEventListener("change", function () {
    updateAssessmentProgress();
    formMessage.textContent = "";
});

// Restart the assessment without clearing the checklist
restartButton.addEventListener("click", function () {
    assessmentForm.reset();

    updateAssessmentProgress();
    formMessage.textContent = "";

    scoreValue.textContent = "--";
    scoreStatus.textContent = "Your result will appear here.";
    scoreExplanation.textContent =
        "Complete all eight questions to calculate your score.";
    resultHeading.textContent = "Your privacy snapshot";

    scoreCircle.style.background =
        "conic-gradient(var(--purple) 0deg, var(--cyan) 0deg, #273149 0deg)";

    recommendationList.replaceChildren();

    const emptyState = document.createElement("div");
    emptyState.className = "empty-state";

    const symbol = document.createElement("span");
    symbol.textContent = "✧";

    const message = document.createElement("p");
    message.textContent =
        "Your recommendations will appear here after assessment.";

    emptyState.append(symbol, message);
    recommendationList.appendChild(emptyState);

    document.getElementById("assessment").scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
});

// Save checklist changes automatically
checklistItems.forEach(item => {
    item.addEventListener("change", function () {
        saveChecklist();
        updateChecklistProgress();
    });
});

// Reset checklist after confirmation
resetChecklistButton.addEventListener("click", function () {
    const confirmed = window.confirm(
        "Reset all checklist items? This cannot be undone."
    );

    if (!confirmed) {
        return;
    }

    checklistItems.forEach(item => {
        item.checked = false;
    });

    saveChecklist();
    updateChecklistProgress();
});

// Initialize the website
restoreChecklist();
updateAssessmentProgress();